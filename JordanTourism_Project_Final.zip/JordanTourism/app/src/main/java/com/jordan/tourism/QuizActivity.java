package com.jordan.tourism;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class QuizActivity extends AppCompatActivity {

    private static final String[] SITE_NAMES = {
        "🏞️ وادي الموجب", "🏛️ أعمدة جرش", "🏰 قلعة عجلون",
        "⚔️ قلعة الكرك", "🌊 العقبة", "🌹 البتراء"
    };

    private static final int[] SITE_IMAGES = {
        R.drawable.site_wadi_mujib, R.drawable.site_jerash, R.drawable.site_ajloun,
        R.drawable.site_karak, R.drawable.site_aqaba, R.drawable.site_petra
    };

    private static final String[] QUESTIONS = {
        "ما هو الاسم الشعبي لوادي الموجب بسبب منظره الرائع؟",
        "في أي حقبة زمنية بُنيت مدينة جرش (جيراسا)؟",
        "من قام ببناء قلعة عجلون في القرن الثاني عشر الميلادي؟",
        "في أي عام بُنيت قلعة الكرك الصليبية؟",
        "ماذا تشتهر العقبة من حيث الطبيعة البحرية؟",
        "بماذا تُعرف مدينة البتراء عالمياً؟"
    };

    private static final String[][] OPTIONS = {
        {"غراند كانيون الأردن", "وادي عربة", "وادي رم", "وادي دانا"},
        {"الحقبة الرومانية", "الحقبة البيزنطية", "الحقبة العباسية", "الحقبة الأموية"},
        {"عز الدين أسامة", "صلاح الدين الأيوبي", "الملك عبدالله", "الأمير زيد"},
        {"1142 ميلادي", "1099 ميلادي", "1200 ميلادي", "1189 ميلادي"},
        {"الشعاب المرجانية", "الأسماك المتحجرة", "الفقمات", "الحيتان الزرقاء"},
        {"المدينة الوردية المنحوتة بالصخر", "مدينة الذهب", "مدينة الأنباط البيضاء", "مدينة الأعمدة"}
    };

    private static final int[] CORRECT_ANSWERS = {0, 0, 0, 0, 0, 0};

    private int siteIndex = 0;
    private int totalScore = 0;
    private boolean answered = false;

    private TextView siteName, questionCounter, questionText, feedbackText;
    private ProgressBar progressBar;
    private ImageView siteImage;
    private MaterialButton option1, option2, option3, option4, nextBtn;
    private MaterialButton[] options;
    private MediaPlayer correctSound, wrongSound;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        siteIndex = getIntent().getIntExtra("siteIndex", 0);
        totalScore = getIntent().getIntExtra("totalScore", 0);

        siteName = findViewById(R.id.siteName);
        questionCounter = findViewById(R.id.questionCounter);
        questionText = findViewById(R.id.questionText);
        feedbackText = findViewById(R.id.feedbackText);
        progressBar = findViewById(R.id.progressBar);
        siteImage = findViewById(R.id.siteImage);
        option1 = findViewById(R.id.option1);
        option2 = findViewById(R.id.option2);
        option3 = findViewById(R.id.option3);
        option4 = findViewById(R.id.option4);
        nextBtn = findViewById(R.id.nextBtn);
        options = new MaterialButton[]{option1, option2, option3, option4};

        progressBar.setMax(6);

        try { correctSound = MediaPlayer.create(this, R.raw.correct); } catch (Exception e) { correctSound = null; }
        try { wrongSound = MediaPlayer.create(this, R.raw.wrong); } catch (Exception e) { wrongSound = null; }

        loadQuestion();
        setupClickListeners();
    }

    private void loadQuestion() {
        answered = false;
        feedbackText.setVisibility(View.GONE);
        nextBtn.setVisibility(View.GONE);

        for (MaterialButton btn : options) {
            btn.setEnabled(true);
            btn.setBackgroundColor(Color.WHITE);
            btn.setTextColor(Color.parseColor("#1A1A1A"));
        }

        siteName.setText(SITE_NAMES[siteIndex]);
        questionCounter.setText("السؤال " + (siteIndex + 1) + " / 6");
        progressBar.setProgress(siteIndex + 1);
        questionText.setText(QUESTIONS[siteIndex]);
        siteImage.setImageResource(SITE_IMAGES[siteIndex]);

        for (int i = 0; i < 4; i++) options[i].setText(OPTIONS[siteIndex][i]);
    }

    private void setupClickListeners() {
        for (int i = 0; i < 4; i++) {
            int idx = i;
            options[i].setOnClickListener(v -> checkAnswer(idx));
        }
        nextBtn.setOnClickListener(v -> goNext());
    }

    private void checkAnswer(int selectedIndex) {
        if (answered) return;
        answered = true;

        for (MaterialButton btn : options) btn.setEnabled(false);

        int correct = CORRECT_ANSWERS[siteIndex];
        options[correct].setBackgroundColor(Color.parseColor("#2E7D32"));
        options[correct].setTextColor(Color.WHITE);

        if (selectedIndex == correct) {
            totalScore++;
            feedbackText.setText("✅ إجابة صحيحة! أحسنت!");
            feedbackText.setTextColor(Color.parseColor("#2E7D32"));
            playSound(true);
        } else {
            options[selectedIndex].setBackgroundColor(Color.parseColor("#C62828"));
            options[selectedIndex].setTextColor(Color.WHITE);
            feedbackText.setText("❌ إجابة خاطئة! الإجابة الصحيحة بالأخضر");
            feedbackText.setTextColor(Color.parseColor("#C62828"));
            playSound(false);
        }

        feedbackText.setVisibility(View.VISIBLE);
        nextBtn.setVisibility(View.VISIBLE);
    }

    private void playSound(boolean correct) {
        try {
            if (correct && correctSound != null) {
                if (correctSound.isPlaying()) correctSound.seekTo(0);
                correctSound.start();
            } else if (!correct && wrongSound != null) {
                if (wrongSound.isPlaying()) wrongSound.seekTo(0);
                wrongSound.start();
            }
        } catch (Exception ignored) {}
    }

    private void goNext() {
        int nextSite = siteIndex + 1;
        if (nextSite >= 6) {
            Intent intent = new Intent(this, VideoActivity.class);
            intent.putExtra("totalScore", totalScore);
            startActivity(intent);
            finish();
        } else {
            Intent intent = new Intent(this, QuizActivity.class);
            intent.putExtra("siteIndex", nextSite);
            intent.putExtra("totalScore", totalScore);
            startActivity(intent);
            finish();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (correctSound != null) correctSound.release();
        if (wrongSound != null) wrongSound.release();
    }
}
