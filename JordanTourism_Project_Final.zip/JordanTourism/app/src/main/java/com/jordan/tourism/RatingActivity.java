package com.jordan.tourism;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class RatingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating);

        RatingBar ratingBar = findViewById(R.id.ratingBar);
        EditText commentText = findViewById(R.id.commentText);
        MaterialButton submitBtn = findViewById(R.id.submitRating);
        TextView thankYouText = findViewById(R.id.thankYouText);

        submitBtn.setOnClickListener(v -> {
            float rating = ratingBar.getRating();
            if (rating == 0) {
                Toast.makeText(this, "يرجى اختيار تقييم بالنجوم أولاً", Toast.LENGTH_SHORT).show();
                return;
            }

            // Hide input elements
            ratingBar.setEnabled(false);
            commentText.setEnabled(false);
            submitBtn.setVisibility(View.GONE);

            // Show thank you
            thankYouText.setVisibility(View.VISIBLE);

            // Build star string
            StringBuilder stars = new StringBuilder();
            for (int i = 0; i < (int) rating; i++) stars.append("⭐");
            thankYouText.setText("شكراً لك! " + stars.toString() + "\n\nنتمنى لك رحلة ممتعة في الأردن الجميل 🇯🇴");
        });
    }
}
