package com.jordan.tourism;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class SitesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sites);

        MaterialButton startQuizBtn = findViewById(R.id.startQuizBtn);
        startQuizBtn.setOnClickListener(v -> {
            Intent intent = new Intent(SitesActivity.this, QuizActivity.class);
            intent.putExtra("siteIndex", 0);
            intent.putExtra("questionIndex", 0);
            intent.putExtra("totalScore", 0);
            startActivity(intent);
        });
    }
}
