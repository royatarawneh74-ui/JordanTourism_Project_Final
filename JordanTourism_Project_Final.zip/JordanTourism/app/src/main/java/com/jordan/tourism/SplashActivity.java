package com.jordan.tourism;

import android.content.Intent;
import android.os.Bundle;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.ScaleAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.logoImage);
        TextView title = findViewById(R.id.titleText);
        TextView subtitle = findViewById(R.id.subtitleText);
        Button startButton = findViewById(R.id.startButton);

        // Animate logo
        AnimationSet logoAnim = new AnimationSet(true);
        ScaleAnimation scale = new ScaleAnimation(0f, 1f, 0f, 1f,
                Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(800);
        AlphaAnimation alpha = new AlphaAnimation(0f, 1f);
        alpha.setDuration(800);
        logoAnim.addAnimation(scale);
        logoAnim.addAnimation(alpha);
        logo.startAnimation(logoAnim);

        // Animate title with delay
        AlphaAnimation titleAnim = new AlphaAnimation(0f, 1f);
        titleAnim.setDuration(600);
        titleAnim.setStartOffset(600);
        titleAnim.setFillAfter(true);
        title.startAnimation(titleAnim);

        AlphaAnimation subtitleAnim = new AlphaAnimation(0f, 1f);
        subtitleAnim.setDuration(600);
        subtitleAnim.setStartOffset(900);
        subtitleAnim.setFillAfter(true);
        subtitle.startAnimation(subtitleAnim);

        AlphaAnimation btnAnim = new AlphaAnimation(0f, 1f);
        btnAnim.setDuration(600);
        btnAnim.setStartOffset(1200);
        btnAnim.setFillAfter(true);
        startButton.startAnimation(btnAnim);

        startButton.setOnClickListener(v -> {
            startActivity(new Intent(SplashActivity.this, SitesActivity.class));
        });
    }
}
