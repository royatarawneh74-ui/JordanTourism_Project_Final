package com.jordan.tourism;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.MediaController;
import android.widget.TextView;
import android.widget.VideoView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class VideoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video);

        int totalScore = getIntent().getIntExtra("totalScore", 0);

        TextView scoreText = findViewById(R.id.scoreText);
        MaterialButton continueBtn = findViewById(R.id.continueBtn);
        VideoView videoView = findViewById(R.id.videoView);
        TextView videoPlaceholder = findViewById(R.id.videoPlaceholder);

        scoreText.setText("نتيجتك: " + totalScore + " / 6");

        // Load local video from res/raw
        try {
            videoPlaceholder.setVisibility(View.GONE);
            videoView.setVisibility(View.VISIBLE);
            MediaController mediaController = new MediaController(this);
            mediaController.setAnchorView(videoView);
            videoView.setMediaController(mediaController);
            String videoPath = "android.resource://" + getPackageName() + "/" + R.raw.jordan_video;
            videoView.setVideoURI(Uri.parse(videoPath));
            videoView.setOnPreparedListener(mp -> {
                mp.setLooping(false);
                videoView.start();
            });
            videoView.setOnErrorListener((mp, what, extra) -> {
                videoView.setVisibility(View.GONE);
                videoPlaceholder.setVisibility(View.VISIBLE);
                return true;
            });
        } catch (Exception e) {
            videoView.setVisibility(View.GONE);
            videoPlaceholder.setVisibility(View.VISIBLE);
        }

        continueBtn.setOnClickListener(v -> {
            startActivity(new Intent(VideoActivity.this, RatingActivity.class));
        });
    }
}
